# leuze_description
Contains the URDF of the scanner and the launch file for independently viewing it.      
Refer to the main README.md of this stack for more information.   
