^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package leuze_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.1 (2019-11-14)
------------------

1.0.0 (2019-11-11)
------------------
* Merge branch 'package_updates' into 'master'
  Package updates
  See merge request ipa326/leuze_ros_drivers!10
* Fix test dependency
* Added author and maintainer info
* Updated README.md of all packages
* Merge branch 'documentation' into 'master'
  Added user documentation for WP1
  See merge request ipa326/leuze_ros_drivers!8
* Added user documentation for WP1
* Merge branch 'refactoring' into 'master'
  Refactoring
  See merge request ipa326/leuze_ros_drivers!7
* added tests for roslaunch
* added License to all packages
* Merge branch 'refactored_architecture' into 'master'
  Refactored architecture
  See merge request ipa326/leuze_ros_drivers!6
* refactored urdf/meshes into leuze_description
* Contributors: Ludovic Delval, Tejas Kumar Shastha, kut
