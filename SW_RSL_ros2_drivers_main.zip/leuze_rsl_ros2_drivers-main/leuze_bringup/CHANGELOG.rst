^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package leuze_bringup
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.1 (2019-11-14)
------------------

1.0.0 (2019-11-11)
------------------
* Merge branch 'package_updates' into 'master'
  Package updates
  See merge request ipa326/leuze_ros_drivers!10
* Added author and maintainer info
* Updated README.md of all packages
* Merge branch 'refactoring' into 'master'
  Refactoring
  See merge request ipa326/leuze_ros_drivers!7
* Fixed errors in packages
* added tests for roslaunch
* Added the phidget driver
* Parametrizing scanner parameters
* Merge branch 'refactored_architecture' into 'master'
  Refactored architecture
  See merge request ipa326/leuze_ros_drivers!6
* created leuze_bringup package
* Contributors: Ludovic Delval, Tejas Kumar Shastha, kut
