^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package leuze_ros_drivers
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.1 (2019-11-14)
------------------

1.0.0 (2019-11-11)
------------------
* Merge branch 'package_updates' into 'master'
  Package updates
  See merge request ipa326/leuze_ros_drivers!10
* Added author and maintainer info
* Updated README.md of all packages
* Merge branch 'refactoring' into 'master'
  Refactoring
  See merge request ipa326/leuze_ros_drivers!7
* added License to all packages
* Added the phidget driver
* Added metapackage
* Contributors: Ludovic Delval, kut
